from pico2d import*

import Background

LEFT, RIGHT = 0,1
Time = 0.01

Scr = 0

class shot:
    def __init__(self, x, y, Direction):
        global Map
        self.x, self.y = x, y;
        self.Direction = Direction;
        self.image = load_image('bullet_basic.png')
        Map = Background.BG()


    def update(self, x):
        global Time,Scr

        Scr = x


        if self.Direction == LEFT:
            self.x -= Time * 800;

        else:
            self.x += Time * 800;


    def draw(self):
        global Scr
        if self.Direction == RIGHT:
            self.image.draw(self.x-Scr ,self.y)
        if self.Direction == LEFT:
            self.image.draw(self.x-Scr ,self.y)

    def get_bb(self):
        return self.x - 12.5, self.y - 12.5, self.x + 12.5, self.y + 12.5
