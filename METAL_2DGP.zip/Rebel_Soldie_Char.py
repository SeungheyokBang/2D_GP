
import Background
from pico2d import *

from Bullet import shot
import Marco_Char

fTime = 0.1
AddValue = 0
ShootTime = 0

bulletContainer = []
Marco = None
Scr = 0
Excute = 0
DistanceX = 1000
Map = None
image=None

MarcoX = 0
MarcoY = 0

def collide(a, x, y):
    left_a, bottom_a, right_a, top_a = a.get_bb()
    #left_b, bottom_b, right_b, top_b = b.get_bb()
    left_b = x - 1.5
    bottom_b = y -1.5
    right_b = x + 1.5
    top_b = y + 1.5

    #self.x - 12.5, self.y - 12.5, self.x + 12.5, self.y + 12.5
    if left_a > right_b:
        return False
    if right_a < left_b:
        return False
    if top_a < bottom_b:
        return False
    if bottom_a > top_b:
        return False

    return True

class Rebel:
     def __init__(self, x , y) :
        global Map, Marco, Excute, MarcoY, MarcoX
        self.x, self.y = 700, 100
        self.Scroll = 0
        self.idle = load_image('REBEL_IDLE.png')
        self.attack = load_image('REBEL_SHOOT.png')
        self.run = load_image('REBEL_RUN.png')
        self.die = load_image('REBEL_die.png')
        self.frame = 0
        self.idle_frame = 0
        self.atk_frame = 0
        self.time =0
        self.w = 90
        self.h = 180

        self.state = 'idle'
        self.alive = 'true'
        self.Setup = False
        #Excute = False

     def scroll(self, x):
         global Scr
         Scr = x

     def Subscribe(self, x, y):
         global DistanceX, MarcoY, MarcoX
         MarcoX = x
         MarcoY = y
         DistanceX = self.x - x;



     def update(self) :
         global AddValue,Scr, DistanceX, Marco, bulletContainer, Excute, MarcoY, MarcoX, ShootTime

         if(self.Setup == False):
            self.Setup = True
            #Marco = Marco_Char.Marco_body()



         if(DistanceX < 400):
             self.state = 'attack'

         else:
             self.state = 'idle'

         AddValue += fTime
         ShootTime += fTime

         if (AddValue > 1):
             AddValue = 0
             self.frame += 1
             if(self.state == 'idle'):
                 if (self.frame > 6):
                     self.frame = 0
             if(self.state == 'attack'):
                 if (self.frame > 2):
                     self.frame = 0
                     if(ShootTime > 10):
                         ShootTime = 0
                         bulletContainer.append(shot(self.x, self.y + 20, 0)); # 적 총알 높이


         for bullet in bulletContainer:
             bullet.update(Scr)
             if collide(bullet, MarcoX, MarcoY):
                  bulletContainer.remove(bullet)




     #  self.atk_frame = (self.atk_frame + 1 ) % 10
     #   self.frame = (self.frame + 1 ) % 11

     def draw(self) :
        global Scr, bulletContainer
        if self.state == 'idle':
            self.idle.clip_draw(self.frame * 100, 200, 100, 100, self.x-Scr, self.y)

        if self.state == 'attack':
           self.attack.clip_draw(self.frame * 200, 200, 100, 100, self.x - 20 -Scr, self.y)
        if self.state == 'die' and self.alive == 'true':
            self.die.clip_draw(self.frame * 100, 200, 100, 100, self.x-Scr, self.y)
            self.alive = 'false'
        if self.state == 'run':
            self.run.clip_draw(self.frame * 100, 200, 100, 100, self.x-Scr, self.y)


        for bullet in bulletContainer:
            bullet.draw()

     def get_bb(self):
        return self.x - 12.5, self.y - 12.5, self.x + 12.5, self.y + 12.5

       # def get_bb(self):
        #    if self.alive == 'true':
         #       return self.x - self.w / 2, self.y + 36 - self.h / 2, self.x + self.w / 2, self.y + 36 + self.h / 2
          #  else:
 #          3     return self.x, self.y, self.x, self.y

#        def draw_bb(self):
 #           if self.alive == 'true':
  #              draw_rectangle(*self.get_bb())






